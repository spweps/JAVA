/**
 * 
 */
/**
 * @author Maelstrom
 *
 */
module BaristaChallenge {
}