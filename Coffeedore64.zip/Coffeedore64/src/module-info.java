/**
 * 
 */
/**
 * @author Maelstrom
 *
 */
module Coffeedore64 {
}