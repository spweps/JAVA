/**
 * 
 */
/**
 * @author Maelstrom
 *
 */
module BankAccount {
}