public class BankAccount {
	
	private double checkingBalance;
	private double savingsBalance;
	public static int numberOfAccounts = 0;
	
	public BankAccount(int checkingBalanceParam, int savingsBalanceParam) {
		checkingBalance = checkingBalanceParam;
		savingsBalance = savingsBalanceParam;
		numberOfAccounts++;
	}
	
	public static int bankAccountCount() {
		return numberOfAccounts;
	}
	
	public int getcheckingBalance() {
		return checkingBalance;
	}
	
	public int getsavingsBalance() {
		return savingsBalance;
	}
	
	public int depositMoney(int amount, String checkingOrSavings) {
		if (checkingOrSavings.equals("Checking")) {
			checkingBalance += amount;
	
		}
		else (checkingOrSavings.equals("Savings")) {
			savingsBalance += amount;
		}
	}
	
	public int withdrawMoney(int amount, String checkingOrSavings) {
		if (checkingOrSavings.equals("Checking")) {
			checkingBalance -= amount;
		}
		else (checkingOrSavings.equals("Savings")) {
			savingsBalance -= amount;
		}
		else if(checkingOrSavings = 0))
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}