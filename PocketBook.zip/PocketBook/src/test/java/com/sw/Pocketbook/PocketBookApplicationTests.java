package com.sw.Pocketbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocketBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
