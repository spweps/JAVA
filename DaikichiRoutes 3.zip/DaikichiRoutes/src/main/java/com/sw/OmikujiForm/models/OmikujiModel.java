package com.sw.OmikujiForm.models;

public class OmikujiModel {
	public int number;
	public String city;
	public String person;
	public String activity;
	public String anything;
	public String controversial;
	

}
