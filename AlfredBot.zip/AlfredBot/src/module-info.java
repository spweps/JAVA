/**
 * 
 */
/**
 * @author Maelstrom
 *
 */
module AlfredBot {
}