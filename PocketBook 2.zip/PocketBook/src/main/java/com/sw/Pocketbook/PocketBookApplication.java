package com.sw.Pocketbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PocketBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocketBookApplication.class, args);
	}

}
