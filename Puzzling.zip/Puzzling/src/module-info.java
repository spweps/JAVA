/**
 * 
 */
/**
 * @author Maelstrom
 *
 */
module Puzzling {
}