module CareSoftInterfaces {
}