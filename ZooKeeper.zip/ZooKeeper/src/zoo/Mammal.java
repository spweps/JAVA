package zoo;

public class Mammal {
	public double energyLevel = 100;
	
	
	
	
	
	
	public double displayEnergy () {
		System.out.println(this.energyLevel);
		return this.energyLevel;
		
	}

}
