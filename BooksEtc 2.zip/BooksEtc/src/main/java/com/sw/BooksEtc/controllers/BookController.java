package com.sw.BooksEtc.controllers;

@Controllers
public class BookController {

}
