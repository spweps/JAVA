module cafeBusinessLogic {
}