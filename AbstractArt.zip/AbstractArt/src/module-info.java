module AbstractArt {
}