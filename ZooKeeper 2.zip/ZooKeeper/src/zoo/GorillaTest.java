package zoo;
public class GorillaTest {

	public static void main(String[] args) {
		
		Gorilla appTest = new Gorilla ();
		
		appTest.throwSomething();
		appTest.throwSomething();
		appTest.throwSomething();
		appTest.eatBananas();
		appTest.eatBananas();
		appTest.climb();
		appTest.displayEnergy();

	}

}
