package zoo;

public class BatTest {

	public static void main(String[] args) {
		
		Bat appTest = new Bat ();
		
		
		appTest.attackTown();
		appTest.attackTown();
		appTest.eatHumans();
		appTest.eatHumans();
		appTest.fly();
		appTest.fly();
		appTest.displayEnergy();

	}

}
