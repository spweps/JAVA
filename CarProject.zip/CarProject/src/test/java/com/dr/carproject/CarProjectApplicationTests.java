package com.dr.carproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
