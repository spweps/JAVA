package com.sw.DaikichiRoutes.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	@RequestMapping("/daikichi")
	public class HomeController {
	    @RequestMapping("")
	    public String index(){
	      return "Welcome to hell...muahahahaha";
	    }
	    @RequestMapping("/daikichi/today")
	    public String hello(){
	      return "You will find despair in all you do";
	    }
	    @RequestMapping("/daikichi/tomorrow")
	    public String world(){
	      return "Tomorrow an opportunity will pass you by and have no power to stop it";
	    }
	}


}
