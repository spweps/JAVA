public class Item {
    
    // MEMBER VARIABLES
    public String name;
    public double price;
}